
module.exports = function event(data){
  //SpellingContestEvent
  let intent = "NewSession";
  if (data.request && data.request.intent){
    intent = data.request.intent.name;
  }
  const timestamp = new Date();
    const self = {
        data,
        "intent": intent,
        "date": timestamp,
        "timestamp": timestamp.getTime()

    };
    self.save = () => {
        console.log("TODO: save " +  self.timestamp );
    }

    return self;
}
